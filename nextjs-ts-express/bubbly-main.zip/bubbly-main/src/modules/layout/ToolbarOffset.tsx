import styled from 'styled-components';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const ToolbarOffset = styled.div(({ theme }) => theme.mixins.toolbar as any);

export default ToolbarOffset;
