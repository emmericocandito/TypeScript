import NotFound404 from '@src/modules/routing/NotFound404';

export default NotFound404;
