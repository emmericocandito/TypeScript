import ChatRoomView from '@src/views/ChatRoomView';

export default ChatRoomView;
