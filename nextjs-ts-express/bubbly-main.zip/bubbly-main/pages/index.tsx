import HomeView from '@src/views/HomeView';

export default HomeView;
