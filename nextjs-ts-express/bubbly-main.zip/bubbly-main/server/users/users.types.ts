import { ID } from '@shared/SharedTypes';

export interface JwtTokenPayload {
  id: ID;
}
