module.exports = {
  rules: {
    'no-restricted-imports': ['error', { patterns: ['@src/*', '**/src/**'] }],
  },
};
